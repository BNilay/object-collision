﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev2
{
    public class Kure
    {
        point3d m;
        int r;

        public int _r
        {
            get => r;
            set => r = value;
        }

        public point3d _m
        {
            get => m;
            set => m = value;
        }

        public Kure()
        {
            _m = new point3d();
            _r = 0;
        }

        public Kure(point3d m2 , int r2)
        {
            _m = m2;
            _r = r2;
        }
    }
}

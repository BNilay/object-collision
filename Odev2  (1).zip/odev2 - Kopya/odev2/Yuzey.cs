﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace odev2
{
    public class Yuzey
    {
        float minX;
        float minY;
        float maxX;
        float maxY;
        float minZ;
        float maxZ;

        public Yuzey(float _minX , float _maxX , float _minY , float _maxY , float _minZ ,float _maxZ ) 
        {
            minX = _minX;
            minY = _minY;
            maxX = _maxX;
            maxY = _maxY;
            minZ = _minZ;
            maxZ = _maxZ;
        }
        public float Minx
        {
            get => minX; 
            set => minX = value;
        }
        public float Miny
        {
            get => minY;
            set => minY = value;
        }
        public float Minz
        {
            get => minZ;
            set => minZ = value;
        }
        public float Maxx
        {
            get => maxX;
            set => maxX = value;
        }
        public float Maxy
        {
            get => maxY;
            set => maxY = value;
        }
        public float Maxz
        {
            get => maxZ;
            set => maxZ = value;
        }
            
    }
}

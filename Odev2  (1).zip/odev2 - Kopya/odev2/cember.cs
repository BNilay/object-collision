﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace odev2
{
    public class cember
    {
        point m;
        int r;

        public cember()
        {
            _m= new point();
            _r = 0;
        }
        public cember(point m, int r)
        {
            _m= m;
            _r = r;
        }

        public point _m
        {
            get => m;
            set => m = value;
        }
        public int _r
        {
            get => r;
            set => r = value;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace odev2
{
    public class dikdortgen
    {
        point m;
        int en;
        int boy;

        public dikdortgen()
        {
            _m=new point();
            _en = 0;
            _boy = 0;
        }

        public dikdortgen(point p, int en, int boy)
        {
            _m = p;
            _en = en;
            _boy = boy;
        }
        public int _en
        {
            get => en;
            set => en = value;
        }
        public int _boy 
        {  get => boy;
           set => boy = value;
        }
        public point _m
        {
            get => m;
            set => m = value;
        }

    }
}

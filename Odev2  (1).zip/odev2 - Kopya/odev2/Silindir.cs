﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace odev2
{
    public class Silindir
    {
        point3d m;
        int r;
        int h;

        public Silindir()
        {
            _m=new point3d();
            _r = 0;
            _h = 0;
        }
        public Silindir(point3d m, int r, int h)
        {
            _m = m;
            _r = r;
            _h = h;
        }

        public point3d _m 
        {
            get => m;
            set => m = value;
        }

        public int _r
        {
            get => r;
            set => r = value;
        }

        public int _h
        {
            get => h;
            set => h = value;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace odev2
{
    public class Prizma
    {
        point3d m;
        int boy;
        int en1;
        int en2;

        public Prizma()
        {
            _m = new point3d();
            _boy = 0;
            _en1 = 0;
            _en2 = 0;
        }

        public Prizma(point3d m2, int boy2, int en1_2, int en2_2)
        {
            _m = m2;
            _boy = boy2;
            _en1 = en1_2;
            _en2 = en2_2;

        }

        public point3d _m
        {
            get => m;
            set => m = value;
        }
        public int _boy
        {
            get => boy;
            set => boy = value;
        }
        public int _en1
        {
            get => en1;
            set => en1 = value;
        }
        public int _en2
        {
            get => en2;
            set => en2 = value;
        }
    }
}

﻿
//                                                    SAKARYA ÜNİVERSİTESİ 
//                                          BİLGİSAYAR VE BİLİŞİM BİLİMLER FAKÜLTESİ
//                                               BİLGİSAYAR MÜHENDİSLİĞİ BÖLÜMÜ
//                                               NESNE DAYALI PROGRAMLAMA DERSİ
// ÖDEV NURAMASI: 2
// ÖĞRENCİ ADI SOYADI: BELKIS NİLAY YILMAZ
// ÖĞRENCİ NUMARASI: B231210376
// SDERS GRUBU: A GRUBU
//***************************************************************************************************************************************  


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace odev2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }
        
            private void button1_Click(object sender, EventArgs e)
            {
                Form2 form2 = new Form2();
                form2.Show();

                // Şu anki formu gizle (isterseniz kapatmak da kullanılabilir)
                this.Hide();
            }

        private void button2_Click(object sender, EventArgs e)
        {


            if (string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text) ||
            string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox4.Text) ||
                string.IsNullOrEmpty(textBox5.Text) || string.IsNullOrEmpty(textBox6.Text) ||
                string.IsNullOrEmpty(textBox7.Text) || string.IsNullOrEmpty(textBox8.Text) ||
                string.IsNullOrEmpty(textBox9.Text) || string.IsNullOrEmpty(textBox10.Text) ||
                string.IsNullOrEmpty(textBox11.Text) || string.IsNullOrEmpty(textBox12.Text) ||
                string.IsNullOrEmpty(textBox13.Text))
            {
                // TextBox boşsa, kullanıcıya uyarı veriyoruz
                MessageBox.Show("Lütfen gerekli değerleri giriniz.", "Uyarı", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Text = "1";
                textBox2.Text = "1";
                textBox3.Text = "1";
                textBox4.Text = "1";
                textBox5.Text = "1";
                textBox6.Text = "1";
                textBox7.Text = "1";
                textBox8.Text = "1";
                textBox9.Text = "1";
                textBox10.Text = "1";
                textBox11.Text = "1";
                textBox12.Text = "1";
                textBox13.Text = "1";




            }








            int s1 = Convert.ToInt32(textBox1.Text) + 450;
            int s2 = Convert.ToInt32(textBox2.Text);
            int s3 = Convert.ToInt32(textBox3.Text);
            int s4 = Convert.ToInt32(textBox4.Text);
            int s5 = Convert.ToInt32(textBox5.Text) + 450;
            int s6 = Convert.ToInt32(textBox6.Text);
            int s7 = Convert.ToInt32(textBox7.Text);
            int s8 = Convert.ToInt32(textBox8.Text);
            int s9 = Convert.ToInt32(textBox9.Text);
            int s10 = Convert.ToInt32(textBox10.Text);
            int s11 = Convert.ToInt32(textBox11.Text);
            int s12 = Convert.ToInt32(textBox12.Text);
            int s13 = Convert.ToInt32(textBox13.Text);








            if (comboBox1.SelectedIndex == 0)
            {
                point nokta = new point(s1, s2);
                dikdortgen dikdortgen1 = new dikdortgen(new point(s5, s6), s7, s8);

                bool carpismaVarMi = Carpisma.noktaDikdortgenCarpisma(nokta, dikdortgen1);


                if (carpismaVarMi == true)
                {
                    MessageBox.Show("Çarpışma var");
                }
                else
                {
                    MessageBox.Show("Çarpışma yok");
                }

                if (checkBox1.Checked)
                {
                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);

                    g.DrawLine(kalem , nokta._x , nokta._y , nokta._x+2,nokta._y+2);
                    g.DrawRectangle(kalem, dikdortgen1._m._x, dikdortgen1._m._y, dikdortgen1._en, dikdortgen1._boy);

                }
            }



            if (comboBox1.SelectedIndex == 1)
                {
                    //nokta-çember




                    point nokta = new point(s1, s2);
                    cember cember1 = new cember(new point(s5, s6), s7);

                    bool carpismaVarMi = Carpisma.noktaCemberCarpisma(nokta, cember1);

                    if (carpismaVarMi == true)
                    {
                        MessageBox.Show("var");
                    }
                    else
                    {
                        MessageBox.Show("yok");
                    }

                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Purple, 1);
                    

                    int merkezCx = cember1._m._x;
                    int merkezCy = cember1._m._y;
                    int Cr = cember1._r;

                    int noktaX = nokta._x;
                    int noktaY = nokta._y;

                    int x = merkezCx - Cr;
                    int y = merkezCy - Cr;
                    int genislik = 2 * Cr;
                    int yukseklik = 2 * Cr;

                    if (checkBox1.Checked)
                    {
                        g.DrawEllipse(kalem, x, y, genislik, yukseklik);
                        g.DrawLine(kalem, noktaX, noktaY, noktaX + 2, noktaY + 2);
                    
                    }
                    



                }
                if (comboBox1.SelectedIndex == 2)
                {
                    //dikdörtgen-dikdöertgen

                    dikdortgen dikdörtgen1 = new dikdortgen(new point(s1, s2), s3, s4);
                    dikdortgen dikdortgen2 = new dikdortgen(new point(s5, s6), s7, s8);

                    bool carpismaVarMı = Carpisma.dikdortgenDikdortgenCarpisma(dikdörtgen1, dikdortgen2);
                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show("var");
                    }
                    else
                    {
                        MessageBox.Show("yok");
                    }
                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);




                    if (checkBox1.Checked)
                    {
                        g.DrawRectangle(kalem, dikdörtgen1._m._x, dikdörtgen1._m._y, dikdörtgen1._en, dikdörtgen1._boy);
                        g.DrawRectangle(kalem, dikdortgen2._m._x , dikdortgen2._m._y, dikdortgen2._en, dikdortgen2._boy);
                    }
                   



                }
                if (comboBox1.SelectedIndex == 3)
                {
                    //dikdörtgen-çember
                    dikdortgen dikdörtgen1 = new dikdortgen(new point(s1, s2), s3, s4);
                    cember cember1 = new cember(new point(s5, s6), s7);


                    bool carpismaVarMı = Carpisma.dikdortgenCember(cember1, dikdörtgen1);

                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show("var");
                    }
                    else
                    {
                        MessageBox.Show("yok");
                    }

                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);


                if (checkBox1.Checked)
                {
                    g.DrawRectangle(kalem, dikdörtgen1._m._x - dikdörtgen1._en, dikdörtgen1._m._y + dikdörtgen1._boy, dikdörtgen1._en, dikdörtgen1._boy);
                    g.DrawEllipse(kalem, cember1._m._x-cember1._r, cember1._m._y+ cember1._r, cember1._r * 2, cember1._r * 2);
                }
                    


                }
                if ((comboBox1.SelectedIndex == 4))
                {
                    //çember-çember
                    cember cember1 = new cember(new point(s1, s2), s3);
                    cember cember2 = new cember(new point(s5, s6), s7);


                    bool carpismaVarMı = Carpisma.cemberCemberCarpisma(cember1, cember2);

                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show("var");
                    }
                    else
                    {
                        MessageBox.Show("yok");
                    }

                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);

                    if (checkBox1.Checked)
                    {
                        g.DrawEllipse(kalem, cember1._m._x -cember1._r , cember1._m._y-cember1._r, cember1._r * 2, cember1._r * 2);
                        g.DrawEllipse(kalem, cember2._m._x- cember2._r, cember2._m._y-cember1._r, cember2._r * 2, cember2._r * 2);
                    }
                   


                }
                if (comboBox1.SelectedIndex == 5)
                {


                    //nokta-küre
                    point3d nokta = new point3d(s1, s2, s3);
                    Kure kure1 = new Kure(new point3d(s5, s6, s7), s8);

                    bool carpismaVarMı = Carpisma.noktaKureCarpisma(nokta, kure1);

                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show("var");
                    }
                    else
                    {
                        MessageBox.Show("yok");
                    }
                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);
                    Brush fırca = new SolidBrush(Color.Orchid);
                    Brush fırca2 = new SolidBrush(Color.Purple);

                    if (checkBox1.Checked)
                    {
               

                    g.DrawLine(kalem,nokta._x,nokta._y,nokta._x+1,nokta._y+1);
                    g.DrawEllipse(kalem,kure1._m._x -kure1._r,kure1._m._y- kure1._r,kure1._r*2,kure1._r*2);
                    g.FillEllipse(fırca, kure1._m._x-kure1._r, kure1._m._y -kure1._r, kure1._r * 2, kure1._r * 2);
                   
                    }



                }
                if ((comboBox1.SelectedIndex == 6))
                {
                    //nokda-prizma
                    point3d nokta1 = new point3d(s1, s2, s3);
                    Prizma prizma1 = new Prizma(new point3d(s5, s6, s7), s8, s9, s10);

                    bool carpismaVarMı = Carpisma.noktaDikdortgenPrizmaCarpisma(nokta1, prizma1);

                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show("var");
                    }
                    else
                    {
                        MessageBox.Show("yok");
                    }

               
                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);
                Pen kalem2 = new Pen(Color.Red, 1);
                Brush fırca = new SolidBrush(Color.Orchid); 
                    Brush fırca2 = new SolidBrush(Color.Plum);

                    int dx1 = prizma1._m._x-prizma1._en1/2;
                int dx2 = prizma1._m._x+prizma1._en1/2;
                int dy1=prizma1._en2;
                g.DrawRectangle(kalem, dx1,dy1, prizma1._en1,prizma1._boy);
                g.DrawRectangle(kalem, dx1, dy1 + prizma1._boy * 2, prizma1._en1 ,prizma1._en2);
                g.DrawLine(kalem, dx1, dy1, dx1, dy1 + prizma1._boy * 2);
                g.DrawLine(kalem, dx1 + prizma1._en1, dy1, prizma1._en1 + dx1, dy1 + prizma1._boy*2);

                g.DrawLine(kalem2,nokta1._x,nokta1._y,nokta1._x+2,nokta1._y+2);
        
                g.DrawLine(kalem, prizma1._en1 * 2 + dx1, dy1 + prizma1._boy * 2 + prizma1._en2 - (prizma1._en2 / 2), prizma1._en1 * 2 + dx1, dy1);
                 g.DrawLine(kalem, dx1 + prizma1._en1, dy1 + prizma1._boy*2+prizma1._en2 , prizma1._en1*2 +dx1 , dy1 + prizma1._boy * 2 + prizma1._en2-(prizma1._en2/2));
                g.DrawLine(kalem,dx1 , dy1,dx1+prizma1._en1*2, dy1);
                
            
            }

            if ((comboBox1.SelectedIndex == 7))
                {
                    //nokta-silindir
                    point3d nokta1 = new point3d(s1, s2, s3);
                    Silindir silindir1 = new Silindir(new point3d(s5, s6, s7), s8, s9);

                    bool carpismaVarMı = Carpisma.noktaSilindir(nokta1, silindir1);

                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show(" çarpışma var");
                    }
                    else
                    {
                        MessageBox.Show("çarpışma yok");
                    }
                int silindiry1 = silindir1._m._y - (silindir1._h / 2);
                int silindiry2= silindir1._m._y + (silindir1._h / 2);



                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);
                g.DrawEllipse(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r + (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                g.DrawEllipse(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r - (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                g.DrawLine(kalem,
    silindir1._m._x + silindir1._h / 2 - silindir1._r + silindir1._r * 2,
    silindiry1,
    silindir1._m._x + silindir1._h / 2 - silindir1._r + silindir1._r * 2,
    silindiry2);
                g.DrawLine(kalem, silindir1._m._x +(silindir1._h / 2) - silindir1._r , silindiry1 ,(silindir1._m._x + silindir1._h / 2) - silindir1._r, silindiry2  );
               // g.DrawLine(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r - (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);


                if (checkBox2.Checked)
                {
                    g.Clear(Color.Thistle);
                }

            }
                if (comboBox1.SelectedIndex == 8)
                {
                    //silindir-siilindir
                    Silindir silindir1 = new Silindir(new point3d(s1, s2, s3), s4, s12);
                    Silindir silindir2 = new Silindir(new point3d(s5, s6, s7), s8, s9);

                    bool carpismaVarMı = Carpisma.silindirSilindirCarpisma(silindir1, silindir2);

                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show(" çarpışma var");
                    }
                    else
                    {
                        MessageBox.Show("çarpışma yok");
                    }
                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);
                   Brush fırca1 = new SolidBrush(Color.Plum);
                Brush fırca2 = new SolidBrush(Color.Orchid);

                int silindiry1 = silindir1._m._y - (silindir1._h / 2);
                int silindiry2 = silindir1._m._y + (silindir1._h / 2);
                int silindiry11 = silindir1._m._y - (silindir1._h / 2);
                int silindiry12 = silindir1._m._y + (silindir1._h / 2);

                g.DrawEllipse(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r + (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                g.DrawEllipse(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r - (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                g.DrawLine(kalem, silindir1._m._x + silindir1._h / 2 - silindir1._r + silindir1._r * 2, silindiry1, silindir1._m._x + silindir1._h / 2 - silindir1._r + silindir1._r * 2, silindiry2);
                g.DrawLine(kalem, silindir1._m._x + (silindir1._h / 2) - silindir1._r, silindiry1, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindiry2);


                g.DrawEllipse(kalem, (silindir2._m._x + silindir2._h / 2) - silindir2._r, silindir2._m._y - silindir2._r + (silindir2._h / 2), silindir2._r * 2, silindir2._r * 2);
                g.DrawEllipse(kalem, (silindir2._m._x + silindir2._h / 2) - silindir2._r, silindir2._m._y - silindir2._r - (silindir2._h / 2), silindir2._r * 2, silindir2._r * 2);
                g.DrawLine(kalem, silindir2._m._x + silindir2._h / 2 - silindir2._r + silindir2._r * 2, silindiry11, silindir2._m._x + silindir2._h / 2 - silindir2._r + silindir2._r * 2, silindiry12);
                g.DrawLine(kalem, silindir2._m._x + (silindir2._h / 2) - silindir2._r, silindiry11, (silindir2._m._x + silindir2._h / 2) - silindir2._r, silindiry12);

                g.FillEllipse(fırca1, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r + (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                g.FillEllipse(fırca2, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r - (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);

                g.FillEllipse(fırca1, (silindir2._m._x + silindir2._h / 2) - silindir2._r, silindir2._m._y - silindir2._r + (silindir2._h / 2), silindir2._r * 2, silindir2._r * 2);
                g.FillEllipse(fırca2, (silindir2._m._x + silindir2._h / 2) - silindir2._r, silindir2._m._y - silindir2._r - (silindir2._h / 2), silindir2._r * 2, silindir2._r * 2);
            }
            if (comboBox1.SelectedIndex == 9)
                {
                    //küre-küre

                    Kure kure1 = new Kure(new point3d(s1, s2, s3), s4);
                    Kure kure2 = new Kure(new point3d(s5, s6, s7), s8);

                    bool carpismaVarMı = Carpisma.kureKure(kure1, kure2);
                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show(" çarpışma var");
                    }
                    else
                    {
                        MessageBox.Show("çarpışma yok");
                    }
                Graphics g = this.CreateGraphics();
                Pen kalem = new Pen(Color.Black, 1);
                Brush fırca = new SolidBrush(Color.Orchid);

                if (checkBox1.Checked)
                {
                    


                    g.DrawEllipse(kalem, kure1._m._x, kure1._m._y, kure1._r * 2, kure1._r * 2);
                    g.FillEllipse(fırca, kure1._m._x, kure1._m._y, kure1._r * 2, kure1._r * 2);

                    g.DrawEllipse(kalem, kure2._m._x, kure2._m._y, kure2._r * 2, kure2._r * 2);
                    g.FillEllipse(fırca, kure2._m._x, kure2._m._y, kure2._r * 2, kure2._r * 2);

                }
                if (checkBox2.Checked)
                {
                    g.Clear(Color.Thistle);
                }
            }
                if (comboBox1.SelectedIndex == 10)
                {
                    //küre-silindir

                    Kure kure1 = new Kure(new point3d(s1, s2, s3), s4);
                    Silindir silindir1 = new Silindir(new point3d(s5, s6, s7), s8, s9);

                    bool carpismaVarMı = Carpisma.kureSilindirCarpisma(kure1, silindir1);
                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show(" çarpışma var");
                    }
                    else
                    {
                        MessageBox.Show("çarpışma yok");
                    }

                Graphics g = this.CreateGraphics();
                Pen kalem = new Pen(Color.Black, 1);
                Brush fırca = new SolidBrush(Color.Orchid);
                Brush fırca1 = new SolidBrush(Color.Plum);
                

                if (checkBox1.Checked)
                {
                    g.DrawEllipse(kalem, kure1._m._x, kure1._m._y, kure1._r * 2, kure1._r * 2);
                    g.FillEllipse(fırca, kure1._m._x, kure1._m._y, kure1._r * 2, kure1._r * 2);

                   
                    int silindiry1 = silindir1._m._y - (silindir1._h / 2);
                    int silindiry2 = silindir1._m._y + (silindir1._h / 2);
                    g.DrawEllipse(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r + (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                    g.DrawEllipse(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r - (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                    g.DrawLine(kalem, silindir1._m._x + silindir1._h / 2 - silindir1._r + silindir1._r * 2, silindiry1, silindir1._m._x + silindir1._h / 2 - silindir1._r + silindir1._r * 2, silindiry2);
                    g.DrawLine(kalem, silindir1._m._x + (silindir1._h / 2) - silindir1._r, silindiry1, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindiry2);

                    g.FillEllipse(fırca1, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r + (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                    g.FillEllipse(fırca, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r - (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);

                }


            }
            if (comboBox1.SelectedIndex == 11)
            {
                //küre- yüzey

                Kure kure1 = new Kure(new point3d(s1, s2, s3), s4);
                bool carpismaVarMı = Carpisma.yuzeyKureCarpisma(s5, s6, s7, s8, s9, s10, kure1);

                if (carpismaVarMı == true)
                {
                    MessageBox.Show(" çarpışma var");
                }
                else
                {
                    MessageBox.Show("çarpışma yok");
                }
                Graphics g = this.CreateGraphics();
                Pen kalem = new Pen(Color.Black, 1);
                Brush fırca = new SolidBrush(Color.Orchid);

                if (checkBox1.Checked)
                {
                    g.DrawEllipse(kalem, kure1._m._x - kure1._r, kure1._m._y- kure1._r, kure1._r * 2, kure1._r * 2);
                    g.FillEllipse(fırca, kure1._m._x - kure1._r, kure1._m._y - kure1._r, kure1._r * 2, kure1._r * 2);

                    g.DrawRectangle(kalem, s5, s6, s7,s8 );
                }


            }
            if (comboBox1.SelectedIndex == 12)
            {
                //prizma-yüzey

                Prizma prizma1 = new Prizma(new point3d(s1, s2, s3), s4, s12, s13);
                bool carpismaVarMı = Carpisma.yuzeuDikdortgenPrizmaCarpisma(s5, s6, s7, s8, s9, s10, prizma1);

                if (carpismaVarMı == true)
                {
                    MessageBox.Show(" çarpışma var");
                }
                else
                {
                    MessageBox.Show("çarpışma yok");
                }

                Graphics g = this.CreateGraphics();
                Pen kalem = new Pen(Color.Black, 1);
                Brush fırca = new SolidBrush(Color.Orchid);

                





                if (checkBox1.Checked)
                {
                    g.DrawRectangle(kalem, s5, s6, s7, s8);
                    int dx1 = prizma1._m._x - prizma1._en1 / 2;
                    int dx2 = prizma1._m._x + prizma1._en1 / 2;
                    int dy1 = prizma1._en2;
                    g.DrawRectangle(kalem, dx1, dy1, prizma1._en1, prizma1._en2);
                    g.DrawRectangle(kalem, dx1, dy1 + prizma1._boy * 2, prizma1._en1, prizma1._en2);
                    g.DrawLine(kalem, dx1, dy1, dx1, dy1 + prizma1._boy * 2);
                    g.DrawLine(kalem, dx1 + prizma1._en1, dy1, prizma1._en1 + dx1, dy1 + prizma1._boy * 2);


                    g.FillRectangle(fırca, dx1, dy1, prizma1._en1, prizma1._en2);
                    g.FillRectangle(fırca, dx1, dy1 + prizma1._boy * 2, prizma1._en1, prizma1._en2);
                }


            }
            if (comboBox1.SelectedIndex == 13)
            {
                //yüzey-silindir

                Silindir silindir1 = new Silindir(new point3d(s1, s2, s3), s4, s12);
                bool carpismaVarMı = Carpisma.yuzeySilindirCarpisma(s5, s6, s7, s8, s9, s10, silindir1);


                if (carpismaVarMı == true)
                {
                    MessageBox.Show(" çarpışma var");
                }
                else
                {
                    MessageBox.Show("çarpışma yok");
                }


                Graphics g = this.CreateGraphics();
                Pen kalem = new Pen(Color.Black, 1);
                Brush fırca = new SolidBrush(Color.Orchid);


                if (checkBox1.Checked)
                {
                    g.DrawRectangle(kalem, s5, s6, s7, s8);

                    g.DrawEllipse(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r + (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                    g.DrawEllipse(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r - (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                    g.DrawLine(kalem, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y + silindir1._h / 2, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r - (silindir1._h / 2));
                    g.DrawLine(kalem, silindir1._m._x + silindir1._h / 2 - silindir1._r + silindir1._r * 2, silindir1._m._y + silindir1._h / 2, silindir1._m._x + silindir1._h / 2 - silindir1._r + silindir1._r * 2, silindir1._m._y - silindir1._r - (silindir1._h / 2));

                    g.FillEllipse(fırca, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r + (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);
                    g.FillEllipse(fırca, (silindir1._m._x + silindir1._h / 2) - silindir1._r, silindir1._m._y - silindir1._r - (silindir1._h / 2), silindir1._r * 2, silindir1._r * 2);

                }


            }
                if ((comboBox1.SelectedIndex == 14))
                {
                    //küre-prizma

                    Kure kure1 = new Kure(new point3d(s1, s2, s3), s4);
                    Prizma prizma1 = new Prizma(new point3d(s5, s6, s7), s8, s9, s10);

                    bool carpismaVarMı = Carpisma.kureDikdortgenPrizma(kure1, prizma1);

                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show(" çarpışma var");
                    }
                    else
                    {
                        MessageBox.Show("çarpışma yok");
                    }
        

                if (checkBox1.Checked)
                {
                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);
                    Brush fırca = new SolidBrush(Color.Orchid);
                    Brush fırca2 = new SolidBrush(Color.Plum);

                    int dx1 = prizma1._m._x - prizma1._en1 / 2;
                    int dx2 = prizma1._m._x + prizma1._en1 / 2;
                    int dy1 = prizma1._en2;
                    g.DrawRectangle(kalem, dx1, dy1, prizma1._en1, prizma1._en2);
                    g.DrawRectangle(kalem, dx1, dy1 + prizma1._boy * 2, prizma1._en1, prizma1._en2);
                    g.DrawLine(kalem, dx1, dy1, dx1, dy1 + prizma1._boy * 2);
                    g.DrawLine(kalem, dx1 + prizma1._en1, dy1, prizma1._en1 + dx1, dy1 + prizma1._boy * 2);

            
                    g.FillRectangle(fırca, dx1, dy1, prizma1._en1, prizma1._en2);
                    g.FillRectangle(fırca2, dx1, dy1 + prizma1._boy * 2, prizma1._en1, prizma1._en2);
                   
                    g.DrawEllipse(kalem, kure1._m._x - kure1._r, kure1._m._y - kure1._r, kure1._r * 2, kure1._r * 2);
                    g.FillEllipse(fırca, kure1._m._x - kure1._r, kure1._m._y - kure1._r, kure1._r * 2, kure1._r * 2);
                }
                }
                if ((comboBox1.SelectedIndex == 15))
                {
                    //prizma-prizma

                    Prizma prizma1 = new Prizma(new point3d(s1, s2, s3), s4, s12, s13);
                    Prizma prizma2 = new Prizma(new point3d(s5, s6, s7), s8, s9, s10);

                    bool carpismaVarMı = Carpisma.prizmaPrizmaCarpisma(prizma1, prizma2);

                    if (carpismaVarMı == true)
                    {
                        MessageBox.Show(" çarpışma var");
                    }
                    else
                    {
                        MessageBox.Show("çarpışma yok");
                    }

                if (checkBox1.Checked)
                {
                    Graphics g = this.CreateGraphics();
                    Pen kalem = new Pen(Color.Black, 1);
                    Brush fırca = new SolidBrush(Color.Orchid);
                    Brush fırca2 = new SolidBrush(Color.Plum);

                    int dx1 = prizma1._m._x - prizma1._en1 / 2;
                    int dx2 = prizma1._m._x + prizma1._en1 / 2;
                    int dy1 = prizma1._en2;
                    g.DrawRectangle(kalem, dx1, dy1, prizma1._en1, prizma1._en2);
                    g.DrawRectangle(kalem, dx1, dy1 + prizma1._boy * 2, prizma1._en1, prizma1._en2);

                    g.DrawLine(kalem, dx1, dy1, dx1, dy1 + prizma1._boy * 2);
                    g.DrawLine(kalem, dx1 + prizma1._en1, dy1, prizma1._en1 + dx1, dy1 + prizma1._boy * 2);


                    g.FillRectangle(fırca, dx1, dy1, prizma1._en1, prizma1._en2);
                    g.FillRectangle(fırca2, dx1, dy1 + prizma1._boy * 2, prizma1._en1, prizma1._en2);
                    

                    int dx12 = prizma2._m._x - prizma2._en1 / 2;
                    int dx22 = prizma2._m._x + prizma2._en1 / 2;
                    int dy12 = prizma2._en2;
                    g.DrawRectangle(kalem, dx12, dy12, prizma2._en1, prizma2._en2);
                    g.DrawRectangle(kalem, dx12, dy12 + prizma2._boy * 2, prizma2._en1, prizma2._en2);
                    g.DrawLine(kalem, dx12, dy12, dx12, dy12 + prizma2._boy * 2);
                    g.DrawLine(kalem, dx12 + prizma2._en1, dy12, prizma2._en1 + dx12, dy12 + prizma2._boy * 2);

                    g.FillRectangle(fırca, dx12, dy12, prizma2._en1, prizma2._en2);
                    g.FillRectangle(fırca2, dx12, dy12 + prizma2._boy * 2, prizma2._en1, prizma2._en2);
                   

                }

            }

            }

            private void textBox4_TextChanged(object sender, EventArgs e)
            {

            }

            private void textBox8_TextChanged(object sender, EventArgs e)
            {

            }

            private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
            {

            if (comboBox1.SelectedIndex == 0)
            {
                gir1.Text = "x:";
                gir2.Text = "y:";

                gir5.Text = "x:";
                gir6.Text = "y:";
                gir7.Text = "en:";
                gir8.Text = "boy:";

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = false;
                gir4.Visible = false;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = false;
                gir10.Visible = false;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true ;
                textBox9.Visible = false;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;
            }

                if (comboBox1.SelectedIndex == 1)
                {
                    textBox3.Visible = false;
                    textBox4.Visible = false;
                    textBox8.Visible = false;
                    textBox9.Visible = false;
                    textBox10.Visible = false;
                    textBox11.Visible = false;
                    textBox12.Visible = false;
                    textBox13.Visible = false;
                    label1.Text = "nokta";
                    label2.Text = "çember";

                gir1.Text = "x:";
                gir2.Text = "y:";
                gir5.Text = "x:";
                gir6.Text = "y:";
                gir7.Text = "r:";

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = false;
                gir4.Visible = false;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = false;
                gir9.Visible = false;
                gir10.Visible = false;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;



            }
            if (comboBox1.SelectedIndex == 2)
                {
                textBox1.Visible = true;
                textBox2.Visible=true;
                textBox3.Visible=true;
                textBox4.Visible=true;
                textBox5.Visible=true;
                textBox6.Visible=true;
                textBox7.Visible=true;
                textBox8.Visible=true; 
                    textBox9.Visible = false;
                    textBox10.Visible = false;
                    textBox11.Visible = false;
                    textBox12.Visible = false;
                    textBox13.Visible = false;

                label1.Text = "dikdörtgen1";
                    label2.Text = "dikdörtgen2";

                gir1.Text = "x=";
                gir2.Text = "y=";
                gir3.Text = "En=";
                gir4.Text = "Boy=";

                gir5.Text = "x=";
                gir6.Text = "y=";
                gir7.Text = "En=";
                gir8.Text = "Boy=";

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = false;

                gir10.Visible = false;
                gir11.Visible = false;
                    gir12.Visible = false;
                    gir13.Visible = false;
                

            }
                if (comboBox1.SelectedIndex == 3)
                {

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;

                textBox8.Visible = false;
                    textBox9.Visible = false;
                    textBox10.Visible = false;
                    textBox11.Visible = false;
                    textBox12.Visible = false;
                textBox13.Visible = false;

                    label1.Text = "dikdörtgen";
                    label2.Text = "çember";

                gir1.Text = "x=";
                gir2.Text = "y=";
                gir3.Text = "En=";
                gir4.Text = "Boy=";

                gir5.Text = "x=";
                gir6.Text = "y=";
                gir7.Text = "r=";

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = false;
                gir9.Visible = false;
                gir10.Visible = false;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;



            }

                if (comboBox1.SelectedIndex == 6)
                {
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
              
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox13.Visible = false;

                textBox4.Visible = false;
                    textBox11.Visible = false;
                    textBox12.Visible = false;
                    label1.Text = "nokta";
                    label2.Text = "prizma";

                gir1.Text = "x=";
                gir2.Text = "y=";
                gir3.Text = "z=";
                

                gir5.Text = "x=";
                gir6.Text = "y=";
                gir7.Text = "z=";
                gir8.Text = "Boy=";
                gir9.Text = "En1=";
                gir10.Text = "En2=";
                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = true;
                gir10.Visible = true;

                gir4.Visible = false;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;
            }
                if (comboBox1.SelectedIndex == 5)
                {

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;

                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox4.Visible = false;
                    textBox9.Visible = false;
                    textBox10.Visible = false;
                    textBox11.Visible = false;
                    textBox12.Visible = false;
                    label1.Text = "nokta";
                    label2.Text = "küre";

                gir1.Text = "x=";
                gir2.Text = "y";
                gir3.Text = "z=";

                gir5.Text = "x=";
                gir6.Text = "y=";
                gir7.Text = "z=";
                gir8.Text = "r=";


                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = false;
                gir10.Visible = false;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;
                gir4.Visible= false;

            }
                if (comboBox1.SelectedIndex == 4)
                {
                    textBox4.Visible = false;
                    textBox8.Visible = false;
                    textBox9.Visible = false;
                    textBox11.Visible = false;
                    textBox10.Visible = false;
                    textBox12.Visible = false;
                    label1.Text = "çember";
                    label2.Text = "çember";

                gir1.Text = "x=";
                gir2.Text = "y=";
                gir3.Text = "r=";

                gir5.Text = "x=";
                gir6.Text = "y=";
                gir7.Text = "r=";

                gir8.Visible= false;
                gir9.Visible = false;
                gir10.Visible = false;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;
                gir4.Visible = false;
            }
                if (comboBox1.SelectedIndex == 7)
                {
                    textBox4.Visible = false;
                    
                    textBox10.Visible = false;
                    textBox11.Visible = false;
                    textBox12.Visible = false;
                    label1.Text = "nokta";
                    label2.Text = "silindir";
                
               gir1.Text = "x=";
                gir2.Text = "y=";
                gir3.Text = "z=";

                gir5.Text = "x=";
                gir6.Text = "y=";
                gir7.Text = "z=";
                gir8.Text = "r=";
                gir9.Text = "h=";

                gir10.Visible = false;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;
                gir4.Visible = false;

            }
                if (comboBox1.SelectedIndex == 8)
                {
             
                    label1.Text = "silindir1";
                    label2.Text = "silindir2";

                gir1.Text = "x:";
                gir2.Text = "y:";
                gir3.Text = "z:";
                gir4.Text = "r:";
                gir12.Text = "h:";

                gir5.Text = "x:";
                gir6.Text = "y:";
                gir7.Text = "z:";
                gir8.Text = "r:";
                gir9.Text = "h:";


                gir1.Visible = true;
                gir2.Visible = true; 
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = true;
                gir10.Visible = false;
                gir12.Visible = true;
                gir11.Visible= false;
                gir13.Visible= false;






                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = true;
                textBox13.Visible = false;

                  



            }
                if (comboBox1.SelectedIndex == 9)
                {
                    label1.Text = "kure1";
                    label2.Text = "kure2";

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = false;
                gir10.Visible = false;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;

                gir1.Text = "x:";
                gir2.Text = "y:";
                gir3.Text = "z:";
                gir4.Text = "r:";

                gir5.Text = "x:";
                gir6.Text = "y:";
                gir7.Text = "z:";
                gir8.Text = "r:";

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = false;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;



            }
            if (comboBox1.SelectedIndex == 10)
                {
                    label1.Text = "kure";
                    label2.Text = "silindir";

                gir1.Text = "x:";
                gir2.Text = "y:";
                gir3.Text = "z:";
                gir4.Text = "r:";

                gir5.Text = "x:";
                gir6.Text = "y:";
                gir7.Text = "z:";
                gir8.Text = "r:";
                gir9.Text = "h:";

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = true;
                gir10.Visible = false;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = false;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;




            }
                if (comboBox1.SelectedIndex == 11)
                {

                    label1.Text = "kure";
                    label2.Text = "yuzey";

                gir1.Text = "x:";
                gir2.Text = "y:";
                gir3.Text = "z:";
                gir4.Text = "r:";

                gir5.Text = "min x:";
                gir6.Text = "min y:";
                gir7.Text = "max x:";
                gir8.Text = "max y:";
                gir9.Text = "min z:";
                gir10.Text = "max z:";

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = true;
                gir10.Visible = true;
                gir11.Visible = false;
                gir12.Visible = false;
                gir13.Visible = false;

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = false;
                textBox12.Visible = false;
                textBox13.Visible = false;





            }
            if (comboBox1.SelectedIndex == 12)
                {
                    label1.Text = "prizma";
                    label2.Text = "yuzey";

                gir1.Text = "x=";
                gir2.Text = "y=";
                gir3.Text = "z=";
                gir4.Text = "Boy=";
                gir12.Text = "En1=";
                gir13.Text = "En2=";

                gir5.Text = "min x:";
                gir6.Text = "min y:";
                gir7.Text = "max x:";
                gir8.Text = "max y:";
                gir9.Text = "min z:";
                gir10.Text = "max z:";

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = true;
                gir10.Visible = true;
                gir11.Visible = false;
                gir12.Visible = true;
                gir13.Visible = true;

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = false;
                textBox12.Visible = true;
                textBox13.Visible = true;








            }
                if (comboBox1.SelectedIndex == 13)
                {

                    textBox11.Visible = false;


                    label1.Text = "silindir";
                    label2.Text = "yuzey";
                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = true;
                gir10.Visible = true;
                gir11.Visible = false;
                gir12.Visible = true;
                gir13.Visible = true;

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
               
                textBox12.Visible = true;
                textBox13.Visible = true;

                gir1.Text = "x=";
                gir2.Text = "y=";
                gir3.Text = "z=";
                gir4.Text = "r=";
                gir12.Text = "Boy";
               

                gir5.Text = "min x:";
                gir6.Text = "min y:";
                gir7.Text = "max x:";
                gir8.Text = "max y:";
                gir9.Text = "min z:";
                gir10.Text = "max z:";



            }
                if (comboBox1.SelectedIndex == 14)
                {

                    label1.Text = "kure";
                    label2.Text = "prizma";
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = false;
                textBox12.Visible = true;
                textBox13.Visible = true;

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = false;
                gir9.Visible = false;
                gir10.Visible = true;
                gir11.Visible = false;
                gir12.Visible = true;
                gir13.Visible = true;

                gir1.Text = "x=";
                gir2.Text = "y=";
                gir3.Text = "z=";
                gir4.Text = "r=";

                gir5.Text = "x=";
                gir6.Text = "y=";
                gir7.Text = "z=";
                gir8.Text = "Boy=";
                gir9.Text = "En1=";
                gir10.Text = "En2=";

            }
                if (comboBox1.SelectedIndex == 15)
                {

                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                textBox6.Visible = true;
                textBox7.Visible = true;
                textBox8.Visible = true;
                textBox9.Visible = true;
                textBox10.Visible = true;
                textBox11.Visible = false;
                textBox12.Visible = true;
                textBox13.Visible = true;

                gir1.Visible = true;
                gir2.Visible = true;
                gir3.Visible = true;
                gir4.Visible = true;
                gir5.Visible = true;
                gir6.Visible = true;
                gir7.Visible = true;
                gir8.Visible = true;
                gir9.Visible = true;
                gir10.Visible = true;
                gir11.Visible = false;
                gir12.Visible = true;
                gir13.Visible = true;

                gir1.Text = "x=";
                gir2.Text = "y=";
                gir3.Text = "z=";
                gir4.Text = "Boy=";
                gir12.Text = "En1=";
                gir13.Text = "En2=";

                gir5.Text = "x=";
                gir6.Text = "y=";
                gir7.Text = "z=";
                gir8.Text = "Boy=";
                gir9.Text = "En1=";
                gir10.Text = "En2=";

                label1.Text = "prizma1";
                    label2.Text = "prizma2";

                }
            }

            private void button3_Click(object sender, EventArgs e)
            {
                Graphics g = this.CreateGraphics();
            g.Clear(Color.Thistle);

            }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }

    // 2 boyutlu point sınıfı
    public class point
        {
            int x;
            int y;

            public point()
            {
                _x = 0;
                _y = 0;
            }

            public point(int x, int y)
            {
                _x = x;
                _y = y;
            }

            public int _x
            {
                get => x;
                set => x = value;
            }

            public int _y
            {
                get => y;
                set => y = value;
            }
        }
        //3 boyutlu point sınıfı 
        public class point3d : point
        {
            int z;

            public point3d()
            {
                _z = 0;
            }
            public point3d(int x, int y, int z)
            {
                _x = x;
                _y = y;
                _z = z;
            }
            public int _z
            {
                get => z;
                set => z = value;
            }
        }
        public static class Carpisma
        {
          

        public static bool noktaDikdortgenCarpisma(point p, dikdortgen d)
        {
            if(p._x >= d._m._x && p._x <= d._m._x + d._en && p._y >= d._m._y && p._y <= d._m._y + d._boy)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

            //nokta - çember 
            public static bool noktaCemberCarpisma(point p, cember c1)
            {
                float disX = p._x - c1._m._x;
                float disY = p._y - c1._m._y;
                float distance = (float)Math.Sqrt((disX * disX) + (disY * disY));

                if (distance <= c1._r)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            //dikdörtgen - dikdörtgen çarpışma
            public static bool dikdortgenDikdortgenCarpisma(dikdortgen d1, dikdortgen d2)
            {

                int Xa = d1._m._x + d1._en / 2;
                int Ya = d1._m._y + d1._boy / 2;
                int Xb = d2._m._x + d2._en / 2;
                int Yb = d2._m._y + d2._boy / 2;

                if (Math.Abs(Xa - Xb) < (d1._en / 2 + d2._en / 2) && Math.Abs(Ya - Yb) < (d1._boy / 2 + d2._boy / 2))
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }

            //dikdörtgen - çember
            public static bool dikdortgenCember(cember c1, dikdortgen d1)
            {
                float testX = c1._m._x;
                float testY = c1._m._y;

                if (c1._m._x < d1._m._x)
                {
                    testX = d1._m._x;
                }
                else if (c1._m._x > d1._m._x + d1._en)
                {
                    testX = d1._m._x + d1._en;
                }

                if (c1._m._y < d1._m._y)
                {
                    testY = d1._m._y;
                }
                else if (c1._m._y > d1._m._y + d1._boy)
                {
                    testY = d1._m._y + d1._boy;
                }

                float disX = c1._m._x - testX;
                float disY = c1._m._y - testY;
                float distance = (float)Math.Sqrt((disX * disX) + (disY * disY));

                if (distance <= c1._r)
                {
                    return true;
                }
                return false;
            }

            // çember - çember çarpışma
            public static bool cemberCemberCarpisma(cember c1, cember c2)
            {
                float d = (float)Math.Sqrt(Math.Pow((c1._m._x - c2._m._x), 2) + Math.Pow((c1._m._y - c2._m._y), 2));
                if ((c1._r + c2._r) > d)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            //nokta - küre çarpışma
            public static bool noktaKureCarpisma(point3d p, Kure k)
            {
                float distance = (float)Math.Sqrt((p._x - k._m._x) * (p._x - k._m._x) + (p._y - k._m._y) * (p._y - k._m._y) + (p._z - k._m._y) * (p._z - k._m._z));

                if (distance <= k._r)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }

            //nokta - dikdörtgen prizma çarpışma

            public static bool noktaDikdortgenPrizmaCarpisma(point3d p, Prizma dp)
            {
                if (p._x >= dp._m._x && p._x <= dp._en1 &&
                    p._y >= dp._m._y && p._y <= dp._m._y + dp._boy &&
                    p._z >= dp._m._z && p._z <= dp._en2 + dp._m._z)
                {
                    return true;
                }
                else { return false; }
            
                            }


            //nokta - silindir çarpışma

            public static bool noktaSilindir(point3d p, Silindir s)
            {
                if (p._x >= s._m._x && p._x <= s._m._x + s._r &&
                    p._y >= s._m._y && p._y <= s._m._y + s._h / 2 &&
                    p._z >= s._m._z && p._z <= s._m._z + s._r)
                {
                    return true;
                }
                else { return false; }

            }

            //silindir - silindir çarpışma 
            public static bool silindirSilindirCarpisma(Silindir s1, Silindir s2)
            {
                point3d p1 = new point3d(s1._m._x, s1._m._y + s1._h / 2, s1._m._z);
                point3d p2 = new point3d(s2._m._x, s2._m._y + s2._h / 2, s2._m._z);

                float d = (float)Math.Sqrt(Math.Pow((p1._x - p2._x), 2) +
                    Math.Pow((p1._y - p2._y), 2) + Math.Pow((p1._z - p2._z), 2));

                if ((s1._r + s2._r) >= (int)d && Math.Abs(p1._y - p2._y) <= (s1._h + s2._h))
                {
                    return true;
                }
                else { return false; }
            }

            //küre - küre çarpışma
            public static bool kureKure(Kure k1, Kure k2)
            {
                float d = (float)(Math.Sqrt(Math.Pow((k1._m._x - k2._m._x), 2) +
                    Math.Pow((k1._m._y - k2._m._y), 2) +
                    Math.Pow(k1._m._z - k2._m._z, 2)));
                if ((k1._r + k2._r) >= (int)d)
                {
                    return true;
                }
                else { return false; }
            }

            //küre - silindir çarpışma
            public static bool kureSilindirCarpisma(Kure k, Silindir s)
            {
                float hipotenüs = (float)(Math.Sqrt(Math.Pow((s._r), 2) + Math.Pow((s._h / 2), 2)));

                float yatay = (float)(Math.Sqrt(Math.Pow((k._m._x - s._m._x), 2) + Math.Pow((k._m._y - s._m._y), 2) + Math.Pow((k._m._z - s._m._z), 2)));
                float dikey = (float)(Math.Sqrt(Math.Pow((k._m._x - s._m._x), 2) + Math.Pow((k._m._y - s._m._y), 2) + Math.Pow((k._m._z - s._m._z), 2)));
                float capraz = (float)(Math.Sqrt(Math.Pow((k._m._x - s._m._x), 2) + Math.Pow((k._m._y - s._m._y), 2) + Math.Pow((k._m._z - s._m._z), 2)));

                if ((k._r + s._r) >= yatay || (s._h / 2 + k._r) >= dikey || (k._r + hipotenüs) > capraz)
                {
                    return true;
                }
                else { return false; }
            }

        //yüzey - küre çarpışma
        public static bool yuzeyKureCarpisma(float _minX, float _minY, float _maxX, float _maxY, float _minZ, float _maxZ, Kure k)
        {
            float closestX = Math.Max(_minX, Math.Min(k._m._x, _maxX));
            float closestY = Math.Max(_minY, Math.Min(k._m._y, _maxY));
            float closestZ = Math.Max(_minZ, Math.Min(k._m._z, _maxZ));

            float distance = (float)(Math.Sqrt(Math.Pow((closestX - k._m._x), 2) +
                Math.Pow((closestY - k._m._y), 2) +
                Math.Pow((closestZ - k._m._z), 2)));

            if (distance <= k._r)
            {
                return true;
            }
            else return false;

            //float yuzeysol = _minX;
            //float yuzeysağ = _maxX;
            //float yuzeyust = _minY;
            //float yuzeyalt = _maxY;
            //float yuzeyon = _minZ;
            //float yuzeyarka = _maxZ;

            //float kuresol = k._m._x - k._r;
            //float kuresag = k._m._x + k._r;
            //float kureust = k._m._y - k._r;
            //float kurealt = k._m._y + k._r;
            //float kureon = k._m._z - k._r;
            //float kurearka = k._m._z + k._r;

            //if (kuresol <= yuzeysağ ||
            //    kuresag >= yuzeysol &&
            //    kureust >= yuzeyalt ||
            //    kurealt <= yuzeyust &&
            //    kureon <= yuzeyalt ||
            //    kurearka >= yuzeyon)
            //{
            //    return true;
            //}
            //else { return false; }



        }


        ////yüzey - dikdörtgen prizma çarpışma
        public static bool yuzeuDikdortgenPrizmaCarpisma(float _minX, float _minY, float _maxX, float _maxY, float _minZ, float _maxZ, Prizma p)
        {
            float prizmaMinX = p._m._x - p._en1 / 2;
            float prizmaMinY = p._m._y - p._boy / 2;
            float prizmaMinZ = p._m._z - p._en2 / 2;

            float prizmaMaxX = p._m._x + p._en1 / 2;
            float prizmaMaxY = p._m._y + p._boy / 2;
            float prizmaMaxZ = p._m._z + p._en2 / 2;

            if (prizmaMinX <= _maxX && prizmaMaxX >= _minX &&
                prizmaMinY <= _maxY && prizmaMaxY >= _minY &&
                prizmaMinZ <= _maxZ && prizmaMaxZ >= _minZ)
            {
                return true;
            }
            else return false;
        }

        //yüzey - silindir çarpışma
        public static bool yuzeySilindirCarpisma(float _minX, float _minY, float _maxX, float _maxY, float _minZ, float _maxZ, Silindir s)
        {
            float tavan = s._m._y - (s._h / 2);
            float taban = s._m._x - (s._h / 2);

            float silindirMinX = s._m._x - s._r;
            float silindirMinY = taban;
            float silindirMinZ = s._m._z - s._r;

            float silindirMaxX = s._m._x + s._r;
            float silindirMaxY = tavan;
            float silindirMaxZ = s._m._z + s._r;

            if (silindirMinX <= _maxX && silindirMaxX >= _minX &&
                silindirMinY <= _maxY && silindirMaxY >= _minY &&
                silindirMinZ <= _maxZ && silindirMaxZ >= _minZ)
            {
                return true;
            }
            else return false;
        }

        //küre - dikdörtgen prizma çarpışma
        public static bool kureDikdortgenPrizma(Kure k, Prizma p)
            {
                //float koseMesafe = (float)Math.Sqrt(Math.Pow((p._en1 / 2), 2) + Math.Pow((p._en2 / 2), 2));
                //float hipotenus = (float)Math.Sqrt(Math.Pow((p._boy / 2), 2) + Math.Pow((koseMesafe), 2));
                //float yatay = (float)Math.Abs(k._m._x - p._m._x); // Yatay uzaklık
                //float dikey = (float)Math.Abs(k._m._y - p._m._y); // Dikey uzaklık
                //float capraz = (float)Math.Sqrt(Math.Pow(k._m._x - p._m._x, 2) + Math.Pow(k._m._y - p._m._y, 2) + Math.Pow(k._m._z - p._m._z, 2)); // Çapraz uzaklık

                ////float yatay = (float)Math.Sqrt(Math.Pow((k._m._x - p._m._x - p._m._x), 2) + Math.Pow((k._m._y - p._m._y), 2) + Math.Pow((k._m._z- p._m._z),2));
                ////float dikey = (float)Math.Sqrt(Math.Pow((k._m._x - p._m._x - p._m._x), 2) + Math.Pow((k._m._y - p._m._y), 2) + Math.Pow((k._m._z - p._m._z), 2));
                ////float capraz = (float)Math.Sqrt(Math.Pow((k._m._x - p._m._x - p._m._x), 2) + Math.Pow((k._m._y - p._m._y), 2) + Math.Pow((k._m._z - p._m._z), 2));

                ////if ((k._r+p._en1/2) > yatay || (p._boy/2 + k._r) > dikey || (k._r + hipotenus > capraz))
                //if ((k._r + p._en1 / 2) > yatay || (k._r + p._en2 / 2) > dikey || (k._r + hipotenus) > capraz)

                //{
                //    return true;
                //}
                //else { return false; }
            float koseMesafe = (float)Math.Sqrt(Math.Pow((p._en1 / 2), 2) + Math.Pow((p._boy / 2), 2));
            float hipotenus = (float)Math.Sqrt(Math.Pow((p._boy / 2), 2) + Math.Pow((p._en1 / 2), 2) + Math.Pow((p._en2 / 2), 2));
            float yatay = (float)Math.Abs(k._m._x - p._m._x); // Yatay uzaklık
            float dikey = (float)Math.Abs(k._m._y - p._m._y); // Dikey uzaklık
            float capraz = (float)Math.Sqrt(Math.Pow(yatay, 2) + Math.Pow(dikey, 2) + Math.Pow(k._m._z - p._m._z, 2)); // Çapraz uzaklık

            if ((k._r + koseMesafe) > yatay && (k._r + koseMesafe) > dikey && (k._r + hipotenus) > capraz)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        //dikdörtgen prizma - dikdörtgen prizma çarpışma
        //public static bool prizmaPrizmaCarpisma(Prizma p1, Prizma p2)
        //{
        //    float kosemesafe = (float)Math.Sqrt(Math.Pow((p1._en1 / 2), 2) + Math.Pow((p1._en1 / 2), 2));
        //    float hipotenus = (float)Math.Sqrt(Math.Pow((p1._boy / 2), 2) + Math.Pow((kosemesafe), 2));

        //    float kosemesafe1 = (float)Math.Sqrt(Math.Pow((p2._en1 / 2), 2) + Math.Pow((p2._en1 / 2), 2));
        //    float hipotenus1 = (float)Math.Sqrt(Math.Pow((p2._boy / 2), 2) + Math.Pow((kosemesafe), 2));

        //    float yatay = (float)Math.Sqrt(Math.Pow((p2._m._x - p1._m._x), 2) + Math.Pow((p2._m._z - p1._m._z), 2) 
        //        + Math.Sqrt(Math.Pow((p2._m._y - p1._m._y), 2)));
        //    float dikey = (float)Math.Sqrt(Math.Pow((p2._m._x - p1._m._x), 2) + Math.Pow((p2._m._z - p1._m._z), 2)
        //        + Math.Sqrt(Math.Pow((p2._m._y - p1._m._y), 2)));

        //    float capraz = (float)Math.Sqrt(Math.Pow((p2._m._x - p1._m._x), 2) + Math.Pow((p2._m._z - p1._m._z), 2)
        //        + Math.Sqrt(Math.Pow((p2._m._y - p1._m._y), 2)));

        //    if ((p2._en1 /2 + p1._en1/2) > yatay || (p1._boy/2+ p2._boy/2)> dikey || (hipotenus+hipotenus1)>capraz)
        //    {
        //        return true;
        //    }
        //    else { return false; }
        //}
        public static bool prizmaPrizmaCarpisma(Prizma p1, Prizma p2)
            {
                // Birinci prizmanın köşegen ve hipotenüs uzunluklarını hesapla
                float kosemesafe1 = (float)Math.Sqrt(Math.Pow((p1._en1 / 2), 2) + Math.Pow((p1._en2 / 2), 2));
                float hipotenus1 = (float)Math.Sqrt(Math.Pow((p1._boy / 2), 2) + Math.Pow((kosemesafe1), 2));

                // İkinci prizmanın köşegen ve hipotenüs uzunluklarını hesapla
                float kosemesafe2 = (float)Math.Sqrt(Math.Pow((p2._en1 / 2), 2) + Math.Pow((p2._en2 / 2), 2));
                float hipotenus2 = (float)Math.Sqrt(Math.Pow((p2._boy / 2), 2) + Math.Pow((kosemesafe2), 2));

                // Yatay, dikey ve çapraz uzaklıkları hesapla
                float yatay = Math.Abs(p2._m._x - p1._m._x);
                float dikey = Math.Abs(p2._m._y - p1._m._y);
                float capraz = (float)Math.Sqrt(Math.Pow((p2._m._x - p1._m._x), 2) + Math.Pow((p2._m._y - p1._m._y), 2) + Math.Pow((p2._m._z - p1._m._z), 2));

                // Çarpışma kontrolü
                if ((p1._en1 / 2 + p2._en1 / 2) > yatay && (p1._boy / 2 + p2._boy / 2) > dikey && (hipotenus1 + hipotenus2) > capraz)
                {
                    return true; // Çarpışma var
                }
                else
                {
                    return false; // Çarpışma yok
                }
            }



        }

       
    }
